﻿namespace Text2Speech
{
    partial class T2S
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnspeak = new System.Windows.Forms.Button();
            this.txttext = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnspeak
            // 
            this.btnspeak.Location = new System.Drawing.Point(109, 140);
            this.btnspeak.Name = "btnspeak";
            this.btnspeak.Size = new System.Drawing.Size(75, 23);
            this.btnspeak.TabIndex = 3;
            this.btnspeak.Text = "Speak";
            this.btnspeak.UseVisualStyleBackColor = true;
            this.btnspeak.Click += new System.EventHandler(this.btnspeak_Click);
            // 
            // txttext
            // 
            this.txttext.Location = new System.Drawing.Point(44, 25);
            this.txttext.Multiline = true;
            this.txttext.Name = "txttext";
            this.txttext.Size = new System.Drawing.Size(216, 84);
            this.txttext.TabIndex = 2;
            // 
            // T2S
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 227);
            this.Controls.Add(this.btnspeak);
            this.Controls.Add(this.txttext);
            this.Name = "T2S";
            this.Text = "T2S";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnspeak;
        private System.Windows.Forms.TextBox txttext;
    }
}