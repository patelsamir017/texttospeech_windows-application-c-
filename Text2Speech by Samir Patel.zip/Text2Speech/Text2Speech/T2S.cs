﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Speech.Recognition;

namespace Text2Speech
{
    public partial class T2S : Form
    {
        SpeechSynthesizer synth = new SpeechSynthesizer();
        public T2S()
        {
            InitializeComponent();
        }

        private void btnspeak_Click(object sender, EventArgs e)
        {
            synth.Volume = 100;  // 0...100  
            synth.Rate = -3;     // -10...10  
            // Synchronous - Speaks the specified text string.  
            synth.Speak(txttext.Text);

            // Asynchronous -   Speaks the specified text string asynchronously.  
            //synth.SpeakAsync(txttext.Text);
        }
    }
}
